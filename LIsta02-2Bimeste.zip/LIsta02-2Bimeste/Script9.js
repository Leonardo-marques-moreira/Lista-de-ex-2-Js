let ipAlunos = document.querySelector("#Alunos");
let ipTurmas = document.querySelector("#Turmas");
let btDividirTurma = document.querySelector("#btDividirTurma");
let H3Resultado = document.querySelector("#H3Resultado");

function DividirTurmas() {
    let Alunos = Number (ipAlunos.value);
    let Turmas = Number (ipTurmas.value);
    
    if (Alunos <= 0 || Turmas <= 0) {
    }

    const AlunosPorTurma = Math.floor(Alunos / Turmas);
    const AlunosSemTurma = Alunos % Turmas;

    H3Resultado.innerHTML ="Cada turma terá "+AlunosPorTurma+" alunos. Alunos sem turma ficará:"+AlunosSemTurma;
}
 btDividirTurma.onclick = function(){
    DividirTurmas();
 }