let ipValorVendido = document.querySelector("#ValorVendido");
let ipValorMeta = document.querySelector("#ValorMeta");
let ipValorMinimoMeta = document.querySelector("#ValorMinimoMeta");
let btCalcularMeta = document.querySelector("#btCalcularMeta");
let H3Resultado = document.querySelector("#H3Resultado");

function CalcularMetas() {
    let ValorVendido = Number(ipValorVendido.value);
    let ValorMeta = Number(ipValorMeta.value);
    let ValorMinimoMeta = Number(ipValorMinimoMeta.value);
    
    let resultado;

    if(ValorVendido >= ValorMeta) {
       resultado = "Meta atingida!";
    } else if (ValorVendido >= ValorMinimoMeta) {
       resultado = "Meta minima atiginda!";
    } else {
        resultado = "Nenhuma meta foi atingida.";
    }

    let PercentualMeta = ((ValorVendido / ValorMeta) * 100).toFixed(2);
    let PercentualMinimoMeta = ((ValorVendido / ValorMinimoMeta) * 100).toFixed(2);

    H3Resultado.innerHTML = resultado + "<br>" +
                            "Percentual de atingimento da meta: " + PercentualMeta + "%<br>" +
                            "Percentual minimo de atingimento da meta: " + PercentualMinimoMeta + "%";
}
btCalcularMeta.onclick = function() {
    CalcularMetas();
}