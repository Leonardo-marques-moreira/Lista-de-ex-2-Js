let ingredientesPorPessoas = document.querySelector("#convidados");
let H3Resultado = document.querySelector("#H3Resultado");
let btCalcularIngredientes = document.querySelector("#btCalcularIngredientes");

function CalcularIngredientes(){

    let convidados = Number(ingredientesPorPessoas.value);

    let ovos = 2 * convidados;
    let queijo = 50 * convidados;

    H3Resultado.innerHTML = "Quantidade de ovos: "+ovos+"<br>"+
                            "Quilogramas de queijo: "+queijo;
}

btCalcularIngredientes.onclick = function() {
    CalcularIngredientes();
}