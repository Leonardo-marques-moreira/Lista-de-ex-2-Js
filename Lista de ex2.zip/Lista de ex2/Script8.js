let ipNumero1 = document.querySelector("#Numero1");
let btCalcularParOuImpar = document.querySelector("#btCalcularParOuImpar");
let H3Resultado = document.querySelector("#H3Resultado");

function CalcularParOuImpar(){
    let Numero1 = Number (ipNumero1.value);

    let resultado;

    if (Numero1 % 2 === 0) {
        resultado = "O número " + Numero1 + " é Par.";
    } else {
        resultado = "O número " + Numero1 + " é Ímpar.";
    }

    H3Resultado.innerText = resultado;
}

btCalcularParOuImpar.onclick = function(){
    CalcularParOuImpar();
}