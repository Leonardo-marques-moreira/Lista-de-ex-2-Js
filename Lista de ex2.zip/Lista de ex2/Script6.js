let ipNotaFinal = document.querySelector("#NotaFinal");
let btCalcularNota = document.querySelector("#btCalcularNota");
let H4Resultado = document.querySelector("#H4Resultado");

function CalcularNota(){
    let NotaFinal = parseFloat(ipNotaFinal.value);

    let resultado;

    if (NotaFinal >= 6){
        resultado = "Aprovado, com nota : "+NotaFinal;
    } else if (NotaFinal >= 4 && NotaFinal < 6){
        resultado = "Precisa fazer prova substitutiva, sua nota foi: "+ NotaFinal;
    } else {
        resultado = "Reprovado, sua nota foi: "+ NotaFinal;
    }

    H4Resultado.innerText = resultado;
}

btCalcularNota.onclick = function(){
    CalcularNota();
}