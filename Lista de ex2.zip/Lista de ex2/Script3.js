let ipValor1 = document.querySelector("#ipValor1");
let ipValor2 = document.querySelector("#ipValor2");
let H3Resultado = document.querySelector("#H3Resultado");
let btCalcular = document.querySelector("#btCalcular");

function CalcularOpBasicas(){

  let Valor1 = Number (ipValor1.value);
  let Valor2 = Number (ipValor2.value);
  
  let adição = Valor1 + Valor2;
  let subtração = Valor1 - Valor2;
  let multiplicação = Valor1 * Valor2;
  let divisão = Valor1 / Valor2;

  H3Resultado.innerHTML = "A adição dos dois valores é: "+adição+"<br>"+
                          "A subtração dos dois valores é: "+subtração+"<br>"+
                          "A multiplicação dos dois valores é: "+multiplicação+"<br>"+
                          "A divisão dos dois valores é: "+divisão;
}

btCalcular.onclick = function(){
    CalcularOpBasicas();
}