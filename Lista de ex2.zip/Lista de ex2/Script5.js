let ipNomeUsuario1 = document.querySelector("#NomeUsuario1");
let ipAnodeNascimento1 = document.querySelector("#AnoDeNascimento1");
let ipNomeUsuario2 = document.querySelector("#NomeUsuario2");
let ipAnodeNascimento2 = document.querySelector("#AnoDeNascimento2");
let ipNomeUsuario3 = document.querySelector("#NomeUsuario3");
let ipAnodeNascimento3 = document.querySelector("#AnoDeNascimento3");
let btCalcularIdade = document.querySelector("#btCalcularIdade");
let H3Resultado = document.querySelector("#H3Resultado");

function CalcularIdade(){
      let NomeUsuario1 = ipNomeUsuario1.value;
      let NomeUsuario2 = ipNomeUsuario2.value;
      let NomeUsuario3 = ipNomeUsuario3.value;

      let AnodeNascimento1 = Number(ipAnodeNascimento1.value);
      let AnodeNascimento2 = Number(ipAnodeNascimento2.value);
      let AnodeNascimento3 = Number(ipAnodeNascimento3.value);

      let currentYear = new Date().getFullYear();
      let Idade1 = currentYear - AnodeNascimento1;
      let Idade2 = currentYear - AnodeNascimento2;
      let Idade3 = currentYear - AnodeNascimento3;

      let pessoas = [
        { nome: NomeUsuario1, idade: Idade1 },
        { nome: NomeUsuario2, idade: Idade2 },
        { nome: NomeUsuario3, idade: Idade3 }
    ];

    pessoas.sort(function(a, b) {
        return b.idade - a.idade;
    });

      H3Resultado.innerHTML = "Pessoa mais velha: " + pessoas[0].nome + " - " + pessoas[0].idade + " anos<br>" +
      "Segunda pessoa mais velha: " + pessoas[1].nome + " - " + pessoas[1].idade + " anos<br>" +
      "Terceira pessoa mais velha: " + pessoas[2].nome + " - " + pessoas[2].idade + " anos";
}

btCalcularIdade.onclick = function(){
    CalcularIdade();
}