      let dolarDefinido = document.querySelector("#dolar");
      let H3Resultado = document.querySelector("#H3Resultado");
      let btCalcularDolar = document.querySelector("#btCalcularDolar");

   function reajuste(){
      
      let dolar = Number(dolarDefinido.value);
      
      let reajuste1 = dolar * 1.01;
      let reajuste2 = dolar * 1.02;
      let reajuste5 = dolar * 1.05;
      let reajuste10 = dolar * 1.10;

         H3Resultado.innerHTML= 
                              "Reajuste 1%:"+reajuste1.toFixed(2)+"<br>"+
                              "Reajuste 2%:"+reajuste2.toFixed(2)+"<br>"+
                              "Reajuste 5%:"+reajuste5.toFixed(2)+"<br>"+
                              "Reajuste 10%:"+reajuste10.toFixed(2);
      }
      btCalcularDolar.onclick = function() {
      reajuste();
      }