let ipSaborPizza1 = document.querySelector("#SaborPizza1");
let ipSaborPizza2 = document.querySelector("#SaborPizza2");
let ipSaborPizza3 = document.querySelector("#SaborPizza3");
let ipSaborPizza4 = document.querySelector("#SaborPizza4");
let ipRefrigerante = document.querySelector("#Refrigerante");
let btCalcular = document.querySelector("#btCalcular");
let H3Resultado = document.querySelector("#H3Resultado");

function CalcularComanda() {
    let SaborPizza1 = ipSaborPizza1.value;
    let SaborPizza2 = ipSaborPizza2.value;
    let SaborPizza3 = ipSaborPizza3.value;
    let SaborPizza4 = ipSaborPizza4.value;
    let Refrigerante = Number(ipRefrigerante.value);

    let SomarSabores = 4 * 12; 
    let SomarRefrigerante = Refrigerante * 7;
    let SomarComanda = SomarSabores + SomarRefrigerante;

    H3Resultado.innerHTML = "O valor total ficou: R$ " + SomarComanda.toFixed(2) + "<br>" +
                            "Sabores escolhidos: " + SaborPizza1 + ", " + SaborPizza2 + ", " + SaborPizza3 + ", " + SaborPizza4 + "<br>" +
                            "Quantidade de refrigerantes: " + Refrigerante + "<br>" +
                            "Valor dos refrigerantes: R$ " + SomarRefrigerante.toFixed(2) + "<br>" +
                            "Valor das pizzas: R$ " + SomarSabores.toFixed(2);
}

btCalcular.onclick = function() {
    CalcularComanda();
}