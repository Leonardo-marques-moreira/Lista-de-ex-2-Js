let ipNumero1 = document.querySelector("#Numero1");
let ipNumero2 = document.querySelector("#Numero2");
let btCalcularMaior = document.querySelector("#btCalcularMaior");
let H3Resultado = document.querySelector("#H3Resultado");

function CalcularMaior (){
         let Numero1 = Number (ipNumero1.value);
         let Numero2 = Number (ipNumero2.value);

    let resultado;

    if (Numero1 > Numero2){
        resultado = "O: "+Numero1+ " é maior que: "+Numero2;
    } else if (Numero1 < Numero2){
        resultado = "O: " +Numero2+ " é maior que: "+Numero1;
    }else{
        resultado = "O: "+Numero2+ " é igual ao: "+Numero1; 
    }

    H3Resultado.innerText = resultado;
}

btCalcularMaior.onclick = function(){
    CalcularMaior();
}